// 请自行修改配置文件
// let fetchUrl = 'http://localhost:8080'

// 请求的路径，端口设置为web服务器监听的端口
let wsUrl = 'ws://47.108.118.35:8080/ws'
let startName = 'Wuhan'
// 起点城市经纬度
let startPos = [114.2662, 30.5851]
